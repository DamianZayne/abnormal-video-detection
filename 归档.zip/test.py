from utils.util import psnr_error, load,load_frame
import tensorflow._api.v2.compat.v1 as tf
tf.compat.v1.disable_eager_execution()
tf.disable_v2_behavior()
import os
from constant import const
from models import prediction_networks_dict
import base64
import io
import uuid
import numpy as np
from PIL import Image
from flask import Flask,render_template,request,Response
import redis
import json
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import load_img, img_to_array,array_to_img
import pathlib
os.environ['CUDA_DEVICES_ORDER'] = "PCI_BUS_ID"
os.environ['CUDA_VISIBLE_DEVICES'] = const.GPUS[0]
dataset_name = const.DATASET
train_folder = const.TRAIN_FOLDER
test_folder = const.TEST_FOLDER
frame_mask = const.FRAME_MASK
pixel_mask = const.PIXEL_MASK
k_folds = const.K_FOLDS
kth = const.KTH
interval = const.INTERVAL
IMAGE_DTYPE = "float32"

IMAGE_QUEUE = "image_queue1"

batch_size = const.BATCH_SIZE
iterations = const.ITERATIONS
num_his = const.NUM_HIS
height, width = const.HEIGHT, const.WIDTH

prednet = prediction_networks_dict[const.PREDNET]
evaluate_name = const.EVALUATE

margin = const.MARGIN
lam = const.LAMBDA

summary_dir = const.SUMMARY_DIR
snapshot_dir = const.SNAPSHOT_DIR
psnr_dir = const.PSNR_DIR
print(const)


folder = 'data/avenue/testing/frames/01'
video_name = '01'
data_path = pathlib.Path(folder)
# 将8张图片加载到内存中，并按顺序排列
print(data_path)



def base64_encode_image(img):
    return base64.b64encode(img).decode("utf-8")


def base64_decode_image(img, dtype):
    img = np.frombuffer(base64.decodebytes(img), dtype=dtype)
    return img

#模型
def model_t(processed_batches,gt):
    train_anchor_output, train_anchor_feature, _ = prednet(processed_batches, use_decoder=True)
    print(train_anchor_output)
    print(gt)
    psnr_tensor = psnr_error(train_anchor_output, gt)
    return train_anchor_output ,psnr_tensor

# sess = tf.Session()
print(data_path)

tf.config.run_functions_eagerly(True)

config = tf.ConfigProto()

db = redis.StrictRedis(host="localhost", port=6379, db=0)

app = Flask(__name__)
@app.route('/up',methods=['GET','POST'])
def up():
    if request.method=='GET':
        return render_template('up.html')
    elif request.method=='POST':
        files = request.files.getlist("myimg")
        # button_value = request.form['button']
        for objfile in files:
            objfile = objfile.read()
            image = Image.open(io.BytesIO(objfile))
            print(type(image))  # <class 'PIL.JpegImagePlugin.JpegImageFile'>
            # 将数组以C语言存储顺序存储
            image = image.copy()
            # 生成图像ID
            k = str(uuid.uuid4())
            s = base64_encode_image((image.convert('RGB')).tobytes())
            print(type(s))
            d = {"id": k, "image": s}
            print('a')
            db.rpush(IMAGE_QUEUE, json.dumps(d))
        imageIDs=[]
    # if button_value == 'Button 1':
        queue = db.lrange(IMAGE_QUEUE, 0, 3)
        video_clip = []
        for q in queue:
            # 获取队列中的图像并反序列化解码
            q = json.loads(q.decode("utf-8"))
            print('b')
            print(type(q['image']))
            image2 = base64_decode_image(q["image"].encode("utf-8"), IMAGE_DTYPE)  # <class 'numpy.ndarray'>
            print(image2)
            video_clip.append(load_frame(image2, height, width))
            imageIDs.append(q["id"])

            # num_batches = len(video_clip) // batch_size
            # image_batches = np.array_split(video_clip, batch_size)  # 4 2 224 224 3
        video_clip = np.stack(video_clip, axis=0)
        video_clip = tf.stack(video_clip, axis=0)
        gt = video_clip[:, -1, ...]
        processed_batches = video_clip[:, 0:4, ...]
        # out,psnr=model_t(processed_batches,gt)
        # out=check(out,psnr)

        with tf.Session(config=config) as sess:

            sess.run(tf.global_variables_initializer())
            print('Init successfully!')
            restore_var = [v for v in tf.global_variables()]

            # loader = tf.train.Saver(var_list=restore_var)
            def inference_func(ckpt, train_anchor_output, psnr_tensor):
                # loader.restore(sess, ckpt)
                print("Restored model parameters from {}".format(snapshot_dir))
                result = sess.run(train_anchor_output)
                p_e = sess.run(psnr_tensor)
                # gt_o = sess.run(gt)
                # print(result)
                # print(gt_o)
                print(p_e)
                predicted_image = array_to_img(result[0])
                plt.imshow(predicted_image)
                plt.axis('off')  # 可选：关闭坐标轴
                plt.show()
                return result

            if os.path.isdir(snapshot_dir):  # 于扫描指定目录下的文件，并将文件名存储在一个集合中。
                def check_ckpt_valid(ckpt_name):
                    is_valid = False
                    ckpt = ''
                    if ckpt_name.startswith('model.ckpt-'):
                        ckpt_name_splits = ckpt_name.split('.')
                        ckpt = str(ckpt_name_splits[0]) + '.' + str(ckpt_name_splits[1])
                        ckpt_path = os.path.join(snapshot_dir, ckpt)
                        if os.path.exists(ckpt_path + '.index') and os.path.exists(ckpt_path + '.meta') and \
                                os.path.exists(ckpt_path + '.data-00000-of-00001'):
                            is_valid = True

                    return is_valid, ckpt

                def scan_psnr_folder():
                    tested_ckpt_in_psnr_sets = set()
                    for test_psnr in os.listdir(psnr_dir):
                        tested_ckpt_in_psnr_sets.add(test_psnr)
                    return tested_ckpt_in_psnr_sets

                def scan_model_folder():
                    saved_models = set()
                    for ckpt_name in os.listdir(snapshot_dir):
                        is_valid, ckpt = check_ckpt_valid(ckpt_name)
                        if is_valid:
                            saved_models.add(ckpt)
                    return saved_models

                tested_ckpt_sets = scan_psnr_folder()
                while True:
                    all_model_ckpts = scan_model_folder()
                    new_model_ckpts = all_model_ckpts - tested_ckpt_sets

                    for ckpt_name in new_model_ckpts:
                        # inference
                        ckpt = os.path.join(snapshot_dir, ckpt_name)
                        result = inference_func(ckpt, processed_batches, gt)
                        tested_ckpt_sets.add(ckpt_name)
                        return result

            db.ltrim(IMAGE_QUEUE, len(imageIDs), -1)






if __name__ =='__main__':
    app.run()
    # video_clips_tensor = tf.placeholder(shape=[1, (num_his + 1), height, width, 3], dtype=tf.float32)  # 1 4 256 256 3
    # inputs = video_clips_tensor[:, 0:num_his, ...]
    # pre = cyclegan_convlstm(inputs=inputs)


